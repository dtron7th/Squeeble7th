makeInstancesUFO -d Roman/Masters/SourceCodePro.designspace
makeInstancesUFO -d Italic/Masters/SourceCodePro-Italic.designspace